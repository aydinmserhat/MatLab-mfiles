clc
clear

x = 0.01;		% x'e soruda istenildigi gibi 0.1 ve 1 de degerleri verip
				% program oyle calistirilmalidir.

toplam = 0;		% toplam degiskeni kumulatif degisken olarak kullanilacak
				% bu yuzden degeri kullanmadan �nce sifirlaniyor
gercek_deger = sin(x);	% bu da sin(x)'in yani bu �rnekte sin(0.01)in
						% ger�ek degeri

for n = 1:3
    us = 2 * n - 1;		% serideki sayilarin usleri: 1, 3, 5
    toplam = toplam + (-1) ^ (n + 1) * x ^ us / factorial(us);
	% serideki toplam ifadesi. (-1) ^ (n + 1) kismi seride bir eksi bir
	% arti olmasini sagliyor. factorial fonksiyonu da sayinin fakt�ryelini
	% d�nd�r�yor.
    hata = abs(toplam - gercek_deger)
	% her seriye tek tek terim eklendiginde toplam degiskeninde olusturulan
	% serinin, ger�ek degerden ne kadar farkli oldugunu belirlemek i�in
	% sayilarin farklarinin mutlak degerini al. ekrana yazdir (noktali virg�l
	% koyulmamis dikkat!) 
end
