
clc
clear

% Re ve Ma degiskenlerini kullanicidan al
r = input('Reynolds (Re) sayisi: ');
m = input('Mach  (Ma)  sayisi  : ');

if (r < 2000)
	% eger r 2000den k���kse sadece burasi �alisacak ve type1
	% degiskenine laminar yazisi atanacak
    type1 = 'Laminar';
elseif (r < 5000)
	% eger r 2000den b�y�kse yukaridaki (r<5000) karsilastirma �alisacak ve r
	% 5000'den k���kse type1 degiskenine transitional yazisi atanacak
    type1 = 'Transitional';
else
	% eger her ikisi de dogru degilse o zaman type1 degiskeninin degeri
	% turbulent yazisi olacak
    type1 = 'Turbulent';
end

if (m < 1)
	% bu karsilastirmada m degiskeni 1'den k���kse type2'ye sub-sonic
	% yazisi atanacak
    type2 = 'Sub-sonic';
elseif (m == 1)
	% eger m < 1 ifadesi yanlissa bir de m == 1 ifadesi �alistirilacak
	% ve eger karsilastirmanin sonucu dogruysa yani m birse type2 degiskenine
	% sonic yazisi atanacak
    type2 = 'Sonic';
else
	% eger hicbiri dogru degilse yani m ne birden k���k ne de bire esit
	% degilse o zaman m yalnizca birden b�y�k olabilir ve bu durumda type2
	% degiskenine super-sonic yazisi atanir.
    type2 = 'Super-Sonic';
end


disp(['Reynolds t�r�: ' type1 '   Mach t�r�: ' type2])
% yukaridaki k�seli parantezlere dikkat ediniz. disp fonksiyonu deger olarak
% bir vekt�r alir. vekt�rler olusturulurken degerlerin arasina bosluk yada
% virg�l konur. �rn. [ 8 6 1 ] yada [ 8, 6, 1 ] gibi.
% bu y�zden yukarida yazilan yazilar ve type1 yada type2 gibi degiskenlerin
% arasinda en az bir bosluk olmasi gerekmektedir.
