
clc
clear

p = zeros(1, 20);	% p degerlerini i�inde tutacagimiz 20 elemanli p
					% vekt�r�n� olustur
p(2) = 2 * sqrt(2);	% p dizisinin ikinci elemani i�in soruda verilen
					% degeri kullaniyoruz

for n = 2:19
    p(n + 1) = 2 ^ n * sqrt(2 * (1 - sqrt(1 - (p(n) / 2 ^ n) ^ 2)));
	% her adimda bir �nceki p degerinden bir sonraki p degeri hesaplaniyor
	% ilk adimda p(2)den hesaplanacagindan n'i 2'den 19'a kadar saydirdik
	% p(2) formulde yerine koyunca p(3), ikinci adimda p(3) form�lde yerine
	% koyunca p(4) ... seklinde her adimda bir sonraki p elemani hesaplaniyor
end

plot(3:20, abs(p(3:20) - pi))
% x'ler 3ten 20ye kadar; buna karsilik gelen formulde hesaplanan p
% degerlerinden pi sayisi �ikariliyor ve mutlak degerleri aliniyor
% hesaplanan pi degerlerinin ger�ek pi degerinden her adimda ne kadar
% farkli oldugunu bir grafikte g�ster.
