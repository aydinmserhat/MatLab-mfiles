
clc
clear

n = input('n degerini gir: ');

% toplam ve Sv degiskenleri tanimlaniyor
toplam = 0;					% toplam bir kumulatif degisken
Sv = zeros(1, n + 1);		% Sv, sigma elemanlarini tutan n+1 boyutunda
							% sifirlardan olusan bir vektor olusturuluyor

for k = 0:n					% k ya sifirdan baslayip bir arttirarak
							% n'ye kadar degerler ver
	toplam = toplam + 1 / (k ^ 2 + 1);
	% toplam degiskeninde k'ya sirayla verilen degerler her adimda �st �ste
	% toplaniyor. 
	Sv(k + 1) = toplam;	% Sv de cizdirmek icin eski degerler saklaniyor
end

plot(0:n, Sv) % sifirdan n'ye kadar olan k degerleri x ekseninde

% Sv'ler ilk n terimin toplami olarak tutuluyor.
% Sv(1) ilk terim, Sv(2) birinciyle ikincinin toplami, Sv(3) ilk �� terim toplami. 
