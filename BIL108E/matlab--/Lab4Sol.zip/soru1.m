
clc
clear all

for limit = logspace(2, 4, 3)
	% limit sirayla [100, 1000, 10000] degerlerini alir
    toplam = 0;
    for n = 1:limit
        toplam = toplam + 1 / n ^ 2;
		% sigma'nin asil hesaplandigi yer burasi
    end
    hata = abs((pi ^ 2 / 6) - toplam);
    disp( [limit, toplam, hata] );
end 