
clc
clear all

kb = 2500;		% kesilmeden birakilan
oran = 0.02;	% yenilen ormanlasma orani
yil = 20;

for k = 1:yil
    kb = kb * (1 + oran);
    fprintf('%d sene sonunda orman %f alana sahiptir.\n', k, kb);
	% yukaridaki %d tamsayi anlaminda
end
