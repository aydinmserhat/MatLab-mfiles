
clc
clear all

t = input('t degerini girin: ');
a = 100;

if t^2 > a
    p = log10(t ^ 2 - a);		% log10 yada log, her ikisi de dogru
else
    p = log10(t ^ 2);
end

fprintf('p nin degeri: %5.3f olmustur.\n', p);
% yukarida %f ondalikli sayi anlaminda. basindaki 5, toplamda 5
% hane kullanilarak yazilacak noktadan sonraki 3 ise ekranda
% 3 ondaligi goster anlaminda.
